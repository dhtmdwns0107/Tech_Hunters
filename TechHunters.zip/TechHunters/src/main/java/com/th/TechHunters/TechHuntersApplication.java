package com.th.TechHunters;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechHuntersApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechHuntersApplication.class, args);
	}

}
