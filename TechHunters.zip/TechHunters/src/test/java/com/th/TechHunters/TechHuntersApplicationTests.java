package com.th.TechHunters;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechHuntersApplicationTests {

	@Test
	void contextLoads() {
	}

}
